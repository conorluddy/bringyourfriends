
/*

	LiftApp
	
	Directions

 */

if (typeof LA.maps === "undefined" || !LA.maps) 
	window.LA.maps = {};




LA.maps.directions = {
	style: {
		polylineOpts: new google.maps.Polyline({
			strokeColor: '#C1FC00',
			strokeOpacity: 0.9,
			strokeWeight: 3
		})
	}
};













